from django.apps import AppConfig


class LandingpagesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "landingPages"
